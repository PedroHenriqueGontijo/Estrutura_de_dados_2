package javasorts;

import java.util.Scanner;


public class bSort {
	public static void bSortComentado(int array[]){
        Scanner scanner = new Scanner(System.in);
        for(int fase=1;fase<array.length;fase++){
            System.out.println("Fase "+fase);//
            JavaSorts.printArray(array);//
            scanner.nextLine();// pause
            boolean parar_verificacao=true;  
           
            for(int comp=0;comp<array.length-fase;comp++){
            	parar_verificacao = false;
            	System.out.println
            	("Comparando "+array[comp]+ " com " + 
            			array[comp+1]);
            	if(array[comp]>array[comp+1]){
            		System.out.println("Trocou");
            		
            		int temp = array[comp];
            		array[comp] = array[comp+1];
            		array[comp+1] = temp;
            		parar_verificacao = true;
            	}// fim if 	
            }  
	            if(parar_verificacao) {            	
	            	break;        
	            }
	       }// for comp   	
	     }// fim for fase
    }// fim bSort
	  

